import React, { useState } from 'react';
import { GlitchText } from '../components/GlitchText';
import { RedactedText } from '../components/RedactedText';

const files = [
  { id: '1', name: 'RESEARCH_PAPER_18B.pdf', size: '2.4 MB', type: 'PDF' },
  { id: '2', name: 'FIELD_NOTES_WARD.txt', size: '14 KB', type: 'TXT' },
  { id: '3', name: 'INCIDENT_REPORT_001.pdf', size: '8.1 MB', type: 'PDF' },
  { id: '4', name: 'EMPLOYEE_HANDBOOK.pdf', size: '1.2 MB', type: 'PDF' },
];

export default function Downloads() {
  const [activeFile, setActiveFile] = useState<string | null>(null);

  const renderFileContent = () => {
    switch(activeFile) {
      case '1':
        return (
          <div className="font-serif bg-white text-black p-8 shadow-inner max-w-2xl mx-auto text-sm">
            <h1 className="text-xl font-bold text-center mb-6 border-b pb-2">Initial Findings: Ambrosia trifida Growth Anomalies</h1>
            <h2 className="font-bold mt-4 mb-2">Abstract</h2>
            <p className="mb-4">Observations of Specimen 18-B indicate a departure from standard botanical growth models. The specimen demonstrates rapid cellular regeneration and an anomalous response to auditory stimuli.</p>
            <h2 className="font-bold mt-4 mb-2">Methodology</h2>
            <p className="mb-4"><span className="bg-black text-black">Redacted text block</span> soil samples were collected at 12-hour intervals. <span className="bg-black text-black">Redacted</span> analysis was performed.</p>
            <h2 className="font-bold mt-4 mb-2">Conclusion</h2>
            <p>Further study required. Patterns are consistent with <span className="bg-black text-black">non-terrestrial biology</span>.</p>
          </div>
        );
      case '2':
        return (
          <div className="font-mono text-[#00ff41] p-4 text-sm whitespace-pre-wrap">
            ENTRY 42: It moved again today. I'm sure of it. Nathan says it's just phototropism but there's no sunlight down here.
            {'\n\n'}
            ENTRY 45: The soil is changing color. Turning grey. Like ash.
            {'\n\n'}
            ENTRY 47: Something is wrong with the light here.
          </div>
        );
      case '3':
        return (
          <div className="font-sans bg-gray-200 text-gray-900 p-8 max-w-2xl mx-auto border-4 border-double border-red-800">
            <h1 className="text-2xl font-black text-red-800 mb-2 uppercase tracking-widest text-center">RESTRICTED INCIDENT REPORT</h1>
            <div className="w-full h-32 bg-black my-6 flex items-center justify-center text-white text-xs">IMAGE REDACTED</div>
            <p className="mb-4">At 0400 hours, alarms triggered in the North Quadrant.</p>
            <p className="bg-black text-black mb-4 inline-block">Large block of text completely redacted to hide what happened.</p>
            <p className="mb-4">Casualties: 0. Personnel requiring psychological evaluation: 3.</p>
          </div>
        );
      case '4':
        return (
          <div className="font-sans bg-white text-black p-8 max-w-2xl mx-auto">
            <h1 className="text-xl font-bold mb-6">DEPARTMENT EMPLOYEE HANDBOOK</h1>
            <h2 className="font-bold mt-4 mb-2">Section 7.3: Standard Working Hours</h2>
            <p className="mb-4">All researchers are expected to maintain core hours of 0900-1700 unless specified by their project lead.</p>
            
            <h2 className="font-bold mt-4 mb-2 text-red-800 border-l-4 border-red-800 pl-2">Section 7.4: Encountering Ecological Anomalies</h2>
            <p className="mb-4 font-serif italic bg-red-50 p-2">If you encounter flora that appears to be mimicking your movements, cease observation immediately. Do not speak to the flora. Do not attempt to burn it; it prefers the heat. Report to your sector head and await quarantine protocol.</p>
            
            <h2 className="font-bold mt-4 mb-2">Section 7.5: Breakroom Etiquette</h2>
            <p className="mb-4">Please clean the microwave after use.</p>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-[#00ff41] border-b border-[#1a3a1a] pb-2">SECURE DOWNLOADS</h2>
      </div>

      {!activeFile ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {files.map(file => (
            <div key={file.id} className="terminal-panel flex items-center justify-between hover:bg-[#001100] transition-colors">
              <div className="flex items-center gap-3">
                <div className="text-[#00ff41]/50">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                    <polyline points="14 2 14 8 20 8" />
                    <line x1="12" y1="18" x2="12" y2="12" />
                    <polyline points="9 15 12 18 15 15" />
                  </svg>
                </div>
                <div>
                  <div className="font-bold">{file.name}</div>
                  <div className="text-xs text-[#00ff41]/50">{file.type} | {file.size}</div>
                </div>
              </div>
              <button 
                className="terminal-button text-xs"
                onClick={() => setActiveFile(file.id)}
              >
                ACCESS
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="flex-1 flex flex-col">
          <div className="mb-4 flex justify-between items-center bg-[#0a0a0a] p-2 border border-[#1a3a1a]">
            <span className="text-[#ffb000]">VIEWING: {files.find(f => f.id === activeFile)?.name}</span>
            <button 
              className="text-[#00ff41] hover:text-white"
              onClick={() => setActiveFile(null)}
            >
              [CLOSE VIEWER]
            </button>
          </div>
          <div className="flex-1 bg-[#050505] border border-[#1a3a1a] p-4 overflow-y-auto">
            {renderFileContent()}
          </div>
        </div>
      )}
    </div>
  );
}
